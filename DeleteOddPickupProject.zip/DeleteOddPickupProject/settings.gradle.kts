rootProject.name = "DeleteOddPickup"
